import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

// DEFINA AQUI O LOGIN E A SENHA FIXOS DO SEU APLICATIVO
const USUARIO_CORRETO = "cliente213";
const SENHA_CORRETA = "cliente213";

export default function App() {
  const [logado, setLogado] = useState(false);
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [imagem, setImagem] = useState(null);

  // Validação do acesso fixo
  const verificarAcesso = () => {
    if (usuario === USUARIO_CORRETO && senha === SENHA_CORRETA) {
      setLogado(true);
    } else {
      Alert.alert('Erro de Acesso', 'Usuário ou senha incorretos.');
    }
  };

  // Função para abrir a câmera ou galeria do celular
  const escolherImagem = async () => {
    const permissao = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (permissao.granted === false) {
      Alert.alert('Permissão necessária', 'Precisamos de acesso às suas fotos para continuar.');
      return;
    }

    let resultado = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!resultado.canceled) {
      setImagem(resultado.assets[0].uri);
    }
  };

  // TELA 1: LOGIN FIXO
  if (!logado) {
    return (
      <View style={styles.container}>
        <Text style={styles.titulo}>Acesso Restrito</Text>
        <TextInput 
          style={styles.input} 
          placeholder="Usuário" 
          autoCapitalize="none"
          value={usuario} 
          onChangeText={setUsuario}
        />
        <TextInput 
          style={styles.input} 
          placeholder="Senha" 
          secureTextEntry 
          autoCapitalize="none"
          value={senha} 
          onChangeText={setSenha}
        />
        <TouchableOpacity style={styles.botao} onPress={verificarAcesso}>
          <Text style={styles.textoBotao}>Entrar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // TELA 2: PÓS-LOGIN (UPLOAD DA FOTO DO BICO)
  return (
    <View style={styles.container}>
      <Text style={styles.tituloPrincipal}>Upload da foto do bico</Text>
      
      <TouchableOpacity style={styles.botaoFoto} onPress={escolherImagem}>
        <Text style={styles.textoBotao}>Selecionar Foto</Text>
      </TouchableOpacity>

      {imagem && (
        <Image source={{ uri: imagem }} style={styles.preview} />
      )}

      {imagem && (
        <TouchableOpacity 
          style={[styles.botao, { backgroundColor: '#28a745' }]}
          onPress={() => Alert.alert('Sucesso', 'Foto enviada com sucesso!')}
        >
          <Text style={styles.textoBotao}>Enviar Foto do Bico</Text>
        </TouchableOpacity>
      )}

      <TouchableOpacity 
        style={styles.botaoSair} 
        onPress={() => { setLogado(false); setImagem(null); setUsuario(''); setSenha(''); }}
      >
        <Text style={styles.textoSair}>Sair do Aplicativo</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8f9fa', padding: 25 },
  titulo: { fontSize: 26, fontWeight: 'bold', marginBottom: 25, color: '#212529' },
  tituloPrincipal: { fontSize: 24, fontWeight: 'bold', marginBottom: 40, color: '#212529', textAlign: 'center' },
  input: { width: '100%', height: 55, backgroundColor: '#fff', borderRadius: 10, paddingHorizontal: 15, marginBottom: 15, borderWidth: 1, borderColor: '#dee2e6', fontSize: 16 },
  botao: { width: '100%', height: 55, backgroundColor: '#007bff', borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginTop: 10 },
  botaoFoto: { width: '100%', height: 55, backgroundColor: '#495057', borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  textoBotao: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  preview: { width: 250, height: 250, borderRadius: 15, marginTop: 10, marginBottom: 20, borderWidth: 1, borderColor: '#ccc' },
  botaoSair: { marginTop: 40 },
  textoSair: { color: '#dc3545', fontSize: 16, fontWeight: '600' }
});
